package com.PeliculasSerbatic.service;

import java.util.List;

import com.PeliculasSerbatic.model.Reseña;
import com.PeliculasSerbatic.model.User;

public interface ReseñaService {
	public List<Reseña> findByUser(User user);
	public Reseña getById(Integer id);
}
