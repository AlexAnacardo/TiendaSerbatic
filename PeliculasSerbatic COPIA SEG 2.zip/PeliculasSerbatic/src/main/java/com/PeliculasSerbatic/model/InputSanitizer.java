package com.PeliculasSerbatic.model;

import org.jsoup.Jsoup;
import org.jsoup.safety.Safelist;

public class InputSanitizer {
    public static String sanitize(String input) {
        return Jsoup.clean(input, Safelist.basic()); // elimina scripts, solo permite HTML básico
    }
}
