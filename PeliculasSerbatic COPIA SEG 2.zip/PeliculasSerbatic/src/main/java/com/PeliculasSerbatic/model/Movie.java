package com.PeliculasSerbatic.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Movie {

	@Id
    private Integer tmdbId;

    private String title;
    private String overview;
    private String posterUrl;

    public Movie() {}

    public Movie(Integer tmdbId, String title, String overview, String posterUrl) {
        this.tmdbId = tmdbId;
        this.title = title;
        this.overview = overview;
        this.posterUrl = posterUrl;
    }

    public Integer getTmdbId() {
        return tmdbId;
    }

    public void setTmdbId(Integer tmdbId) {
        this.tmdbId = tmdbId;
    }

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public String getPosterUrl() {
		return posterUrl;
	}

	public void setPosterUrl(String posterUrl) {
		this.posterUrl = posterUrl;
	}
    
    
}
