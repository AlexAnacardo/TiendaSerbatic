package com.PeliculasSerbatic.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class PeliculaFavoritaVO {
    @Id @GeneratedValue
    private Long id;

    private String title;
    private String overview;
    private String posterUrl;

    @ManyToOne
    private UsuarioVO user;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public String getPosterUrl() {
		return posterUrl;
	}

	public void setPosterUrl(String posterUrl) {
		this.posterUrl = posterUrl;
	}

	public UsuarioVO getUser() {
		return user;
	}

	public void setUser(UsuarioVO user) {
		this.user = user;
	}

    
}
