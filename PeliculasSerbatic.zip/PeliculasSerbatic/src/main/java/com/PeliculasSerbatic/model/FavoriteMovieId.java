package com.PeliculasSerbatic.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class FavoriteMovieId implements Serializable {

	@Column(name = "email_usuario")
    private String email;

    @Column(name = "movie_id")
    private Integer movieId;

    public FavoriteMovieId() {}

    public FavoriteMovieId(String email, Integer movieId) {
        this.email = email;
        this.movieId = movieId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getMovieId() {
        return movieId;
    }

    public void setMovieId(Integer movieId) {
        this.movieId = movieId;
    }
}
