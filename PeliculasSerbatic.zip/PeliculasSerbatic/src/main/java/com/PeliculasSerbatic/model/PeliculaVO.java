package com.PeliculasSerbatic.model;

public class PeliculaVO {
    private String title;
    private String overview;
    private String posterUrl;

    public PeliculaVO(String title, String overview, String posterUrl) {
        this.title = title;
        this.overview = overview;
        this.posterUrl = posterUrl;
    }

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public String getPosterUrl() {
		return posterUrl;
	}

	public void setPosterUrl(String posterUrl) {
		this.posterUrl = posterUrl;
	}

    
}
