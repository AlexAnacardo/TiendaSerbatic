package com.PeliculasSerbatic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PeliculasSerbatic.model.PeliculaFavoritaVO;
import com.PeliculasSerbatic.model.UsuarioVO;

@Repository
public interface FavoriteMovieRepository extends JpaRepository<PeliculaFavoritaVO, Long> {
    List<PeliculaFavoritaVO> findByUser(UsuarioVO user);
}
