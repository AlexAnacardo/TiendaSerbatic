package com.PeliculasSerbatic.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.PeliculasSerbatic.model.Reseña;

import java.util.List;

public interface ReseñaRepository extends JpaRepository<Reseña, Integer> {
    List<Reseña> findByMovieTmdbId(Integer tmdbId);
}
