package com.PeliculasSerbatic;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeliculasSerbaticApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeliculasSerbaticApplication.class, args);
	}

}
