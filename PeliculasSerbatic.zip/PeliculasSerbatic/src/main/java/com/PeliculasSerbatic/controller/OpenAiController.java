package com.PeliculasSerbatic.controller;

import com.PeliculasSerbatic.model.Answer;
import com.PeliculasSerbatic.model.Question;
import com.PeliculasSerbatic.model.Movie;
import com.PeliculasSerbatic.service.OpenAiService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class OpenAiController {

    @Autowired
    private OpenAiService openAiService;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${tmdb.api.key}")
    private String apiKey;

    @PostMapping("/recomendarSimilares")
    public String recomendarSimilares(@RequestParam("title") String nombrePelicula, HttpSession session, Model model) {
        try {
            // Pregunta a la IA
            Question question = new Question("Dame 5 películas similares (en genero, pais de origen, estilo y argumento, por ejemplo, si te paso una pelicula de accion, recomiendame peliculas de accion parecidas, si te paso una pelicula de romance, recomiendame peliculas de romance parecidas, si te paso una pelicula de anime, recomiendame peliculas de anime parecidas) a \"" + nombrePelicula + "\". " +"Solo quiero sus IDs de The Movie Database (TMDB), sin nombres, sin texto adicional ni indices ni numeracion, uno por línea, solo números, por supuesto, no recomiendes ninguna pelicula pornografica.");
            Answer answer = openAiService.getAnswer(question);            
            
            // Extrae los IDs de la respuesta (asumiendo que vienen como lista de números)
            List<Integer> ids = Arrays.stream(answer.answer().split("[,\\n]"))
                    .map(String::trim)
                    .filter(s -> s.matches("\\d+"))
                    .map(Integer::valueOf)
                    .collect(Collectors.toList());

            // Llama a TMDB por cada ID
            List<Movie> peliculasRecomendadas = ids.stream().map(id -> {
                try {
                    String url = "https://api.themoviedb.org/3/movie/" + id + "?api_key=" + apiKey + "&language=es-ES";
                    ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
                    Map<String, Object> result = response.getBody();

                    String title = (String) result.get("title");
                    String overview = (String) result.get("overview");
                    String posterUrl = "https://image.tmdb.org/t/p/w500" + result.get("poster_path");

                    return new Movie(id, title, overview, posterUrl);
                } catch (Exception e) {
                    System.err.println("⚠️ Error con ID TMDB " + id + ": " + e.getMessage());
                    return null;
                }
            }).filter(Objects::nonNull).collect(Collectors.toList());

            session.setAttribute("recomendacionesIA", peliculasRecomendadas);           
            
        } catch (Exception e) {
            System.err.println("⚠️ Error general recomendando: " + e.getMessage());
        }

        return "redirect:/recomendacionesIA";
    }
    
    @GetMapping("/recomendacionesIA")
    public String verRecomendaciones(HttpSession session, Model model) {
        List<Movie> recomendaciones = (List<Movie>) session.getAttribute("recomendacionesIA");
        model.addAttribute("recomendaciones", recomendaciones);
        return "recomendacionesIA";
    }

}
