package com.PeliculasSerbatic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.PeliculasSerbatic.model.Movie;
import com.PeliculasSerbatic.model.Reseña;
import com.PeliculasSerbatic.model.User;
import com.PeliculasSerbatic.repository.MovieRepository;
import com.PeliculasSerbatic.repository.ReseñaRepository;
import com.PeliculasSerbatic.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UsuarioController {
	
	@Autowired
	UserService service;
	
	
	@Autowired
	private ReseñaRepository reviewRepo;
	
	@Autowired
	private MovieRepository movieRepo;

	@PostMapping("/agregarReseña")
	public String addReview(@RequestParam("tmdbId") Integer tmdbId, 
	                        @RequestParam("content") String content, 
	                        HttpSession session, 
	                        Model model) {

	    User user = (User) session.getAttribute("usuarioEnCurso");

	    if (user != null) {
	        Movie movie = movieRepo.findById(tmdbId).orElse(null);

	        if (movie != null) {
	            // Comprobar si ya existe una reseña del usuario
	            Reseña existingReview = reviewRepo.findByMovieTmdbId(tmdbId).stream()
	                    .filter(r -> r.getUser().getEmail().equals(user.getEmail()))
	                    .findFirst()
	                    .orElse(null);

	            if (existingReview != null) {
	                // Editar la reseña existente
	                existingReview.setContent(content);
	                reviewRepo.save(existingReview);
	            } else {
	                // Crear una nueva reseña
	            	Reseña newReview = new Reseña(null, content, movie, user);
	                reviewRepo.save(newReview);
	            }

	            return "redirect:/verMas?tmdbId=" + tmdbId; // Volver a la página de detalles
	        }
	    }

	    return "redirect:/login";  // Redirigir a login si no está autenticado
	}

	@PostMapping("/eliminarReseña")
	public String deleteReview(@RequestParam("tmdbId") Integer tmdbId, 
	                           @RequestParam("reviewId") Integer reviewId, 
	                           HttpSession session) {

	    User user = (User) session.getAttribute("usuarioEnCurso");

	    if (user != null) {
	        Reseña review = reviewRepo.findById(reviewId).orElse(null);

	        if (review != null && review.getUser().getEmail().equals(user.getEmail())) {
	            // Eliminar la reseña
	            reviewRepo.delete(review);
	        }
	    }

	    return "redirect:/verMas?tmdbId=" + tmdbId;  // Redirigir de nuevo a la página de detalles
	}
	

}
