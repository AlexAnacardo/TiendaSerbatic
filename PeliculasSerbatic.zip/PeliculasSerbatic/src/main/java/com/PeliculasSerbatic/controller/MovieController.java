package com.PeliculasSerbatic.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.PeliculasSerbatic.model.Actor;
import com.PeliculasSerbatic.model.FavoriteMovie;
import com.PeliculasSerbatic.model.FavoriteMovieId;
import com.PeliculasSerbatic.model.Movie;
import com.PeliculasSerbatic.model.MovieDetails;
import com.PeliculasSerbatic.model.Reseña;
import com.PeliculasSerbatic.model.User;
import com.PeliculasSerbatic.repository.FavoriteMovieRepository;
import com.PeliculasSerbatic.repository.MovieRepository;
import com.PeliculasSerbatic.repository.ReseñaRepository;
import com.PeliculasSerbatic.service.MovieService;
import com.PeliculasSerbatic.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class MovieController {

    @Autowired
    private MovieService movieService;

    @Autowired
    private FavoriteMovieRepository favoriteRepo;
    
    @Autowired
    private MovieRepository movieRepo;
    
    @Autowired
    private ReseñaRepository reviewRepo;

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String index(Model model, HttpSession session) {
        List<Movie> trending = movieService.getTrendingMovies(); 
        model.addAttribute("movies", trending);
        session.setAttribute("cabeceraPagina", "Buscador de peliculas");
        
        return "index";
    }

    @PostMapping("/search")
    public String search(@RequestParam("query") String query, Model model) {
        List<Movie> movies = movieService.searchMovies(query);
        model.addAttribute("movies", movies);
        return "index";
    }
    
    

    @PostMapping("/añadirFavorita")
    public String addFavorite(@RequestParam("tmdbId") Integer tmdbId,
                              @RequestParam("title") String title,
                              @RequestParam("overview") String overview,
                              @RequestParam("posterUrl") String posterUrl,
                              HttpSession session) {

        User user = (User) session.getAttribute("usuarioEnCurso");

        if (user != null) {
            // Buscar o crear la película por ID
            Movie movie = movieRepo.findById(tmdbId).orElseGet(() -> {
                Movie newMovie = new Movie(tmdbId, title, overview, posterUrl);
                return movieRepo.save(newMovie);
            });

            // Crear ID compuesto
            FavoriteMovieId favId = new FavoriteMovieId(user.getEmail(), movie.getTmdbId());

            // Verificar si ya existe como favorita
            if (!favoriteRepo.existsById(favId)) {
                FavoriteMovie favorite = new FavoriteMovie();
                favorite.setId(favId);
                favorite.setUser(user);
                favorite.setMovie(movie);
                favoriteRepo.save(favorite);
            }

            return "redirect:/";
        } else {
            return "redirect:/goLogin";
        }
    }

    @PostMapping("/eliminarFavorita")
    public String deleteFavorite(@RequestParam("tmdbId") Integer tmdbId, HttpSession session) {

        User user = (User) session.getAttribute("usuarioEnCurso");
        
        favoriteRepo.deleteById(new FavoriteMovieId(user.getEmail() ,tmdbId));
        
        return "redirect:/favorites";
    }

    @GetMapping("/favorites")
    public String favorites(Model model, HttpSession session) {
        // Obtener el usuario actual de la sesión
        User usuarioEnCurso = (User) session.getAttribute("usuarioEnCurso");

        if (usuarioEnCurso != null) {
            // Buscar las películas favoritas asociadas al email del usuario
            List<FavoriteMovie> favoriteMovies = favoriteRepo.findByUserEmail(usuarioEnCurso.getEmail());

            // Extraer las películas favoritas de la lista de FavoriteMovie
            List<Movie> movies = favoriteMovies.stream()
                                               .map(FavoriteMovie::getMovie)  // Obtener la película desde FavoriteMovie
                                               .collect(Collectors.toList());

            model.addAttribute("favorites", movies);  // Pasar las películas al modelo
            session.setAttribute("cabeceraPagina", "Listado de peliculas favoritas");
            
            return "favorites";  // Devolver la vista de favoritas
        } else {
        	return "login";
        } 
    }
    
    
    @Value("${tmdb.api.key}")  // Inyectar la API key desde el archivo de propiedades
    private String apiKey;
    
    
    @GetMapping("/verMas")
    public String verDetalles(@RequestParam("tmdbId") Integer tmdbId, Model model) {
        Optional<MovieDetails> optionalDetails = obtenerDetallesDePelicula(tmdbId);

        if (optionalDetails.isPresent()) {
        	List<Actor> cast = obtenerReparto(tmdbId);
        	List<Reseña> reviews = reviewRepo.findByMovieTmdbId(tmdbId);
        	model.addAttribute("reparto", cast);
            model.addAttribute("movieDetails", optionalDetails.get());
            model.addAttribute("reviews", reviews);
            model.addAttribute("idPelicula", tmdbId);
        } else {
            model.addAttribute("movieDetails", null);
            model.addAttribute("error", "No se encontraron detalles de la película o ocurrió un error al conectarse con la API.");
        }

        return "detallesPelicula";
    }

    public Optional<MovieDetails> obtenerDetallesDePelicula(Integer tmdbId) {
        try {
            String url = "https://api.themoviedb.org/3/movie/" + tmdbId + "?api_key=" + apiKey + "&language=es-ES";
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject jsonResponse = new JSONObject(response.toString());

            String title = jsonResponse.getString("title");
            String overview = jsonResponse.getString("overview");
            String posterPath = jsonResponse.optString("poster_path", "");
            String releaseDate = jsonResponse.optString("release_date", "Desconocida");
            Double popularity = jsonResponse.optDouble("popularity", 0.0);
            String posterUrl = "https://image.tmdb.org/t/p/w500" + posterPath;

            MovieDetails movieDetails = new MovieDetails(title, overview, posterUrl, releaseDate, popularity);
            return Optional.of(movieDetails);

        } catch (Exception e) {
            e.printStackTrace();
            return Optional.empty();
        }
    }

    public List<Actor> obtenerReparto(Integer tmdbId) {
        List<Actor> reparto = new ArrayList<>();
        try {
            String url = "https://api.themoviedb.org/3/movie/" + tmdbId + "/credits?api_key=" + apiKey + "&language=es-ES";
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject json = new JSONObject(response.toString());
            JSONArray castArray = json.getJSONArray("cast");

            for (int i = 0; i < Math.min(10, castArray.length()); i++) {
                JSONObject actorJson = castArray.getJSONObject(i);
                String name = actorJson.getString("name");
                String character = actorJson.getString("character");
                String profilePath = actorJson.optString("profile_path", null);
                String profileUrl = (profilePath != null) ? "https://image.tmdb.org/t/p/w185" + profilePath : "https://via.placeholder.com/185x278?text=Sin+Foto";

                reparto.add(new Actor(name, profileUrl));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return reparto;
    }


}
