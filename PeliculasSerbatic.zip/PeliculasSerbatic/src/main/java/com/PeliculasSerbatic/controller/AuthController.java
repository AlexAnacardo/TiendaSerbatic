package com.PeliculasSerbatic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.PeliculasSerbatic.model.User;
import com.PeliculasSerbatic.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;
    
    @GetMapping("/goLogin")
    public String goLogin(HttpSession sesion) {
    	sesion.setAttribute("cabeceraPagina", "Iniciar sesion");
        return "login";
    }
    

    @PostMapping("/login")
    public String hacerLogin(@RequestParam(name = "user") String email, @RequestParam(name = "pass") String pass, Model model, HttpSession sesion) {
		
		User usuario = userService.getByEmail(email);
		
		if(usuario!=null && usuario.getPassword().equals(pass)) {
			
			sesion.setAttribute("usuarioEnCurso", usuario);			

			return "redirect:/";
		}
		else {
			return "login";
		}
    }
    
    @GetMapping("/logout")
    public String hacerLogout(HttpSession sesion) {
    	
    	sesion.removeAttribute("usuarioEnCurso");
    	
    	return "redirect:/";
    }
    
    @GetMapping("/goRegister")
    public String goRegister(HttpSession sesion) {
    	sesion.setAttribute("cabeceraPagina", "Registrarse");
        return "register";
    }

    @PostMapping("/register")
    public String processRegister(@RequestParam String email, @RequestParam String username, @RequestParam String password, HttpSession sesion) {   	
    	
    	if(userService.getByEmail(email)==null) {
    		User usuario=new User(email, username, password);    	
        	
        	userService.register(usuario.getEmail(), usuario.getUsername(), usuario.getPassword());
        	
        	sesion.setAttribute("usuarioEnCurso", usuario);
        	
            return "redirect:/";
    	} else {
    		return "register";
    	}
    	
    	
    }
    
}
