package com.PeliculasSerbatic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.PeliculasSerbatic.model.PeliculaFavoritaVO;
import com.PeliculasSerbatic.model.PeliculaVO;
import com.PeliculasSerbatic.model.UsuarioVO;
import com.PeliculasSerbatic.repository.FavoriteMovieRepository;
import com.PeliculasSerbatic.service.MovieService;
import com.PeliculasSerbatic.service.UserService;

@Controller
public class PeliculaController {

    @Autowired
    private MovieService movieService;

    @Autowired
    private FavoriteMovieRepository favoriteRepo;

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String index(Model model) {
        List<PeliculaVO> trending = movieService.getTrendingMovies(); // top N
        model.addAttribute("movies", trending);
        return "index";
    }

    @PostMapping("/search")
    public String search(@RequestParam String query, Model model) {
        List<PeliculaVO> movies = movieService.searchMovies(query);
        model.addAttribute("movies", movies);
        return "index";
    }

    @PostMapping("/favorites/add")
    public String addFavorite(@RequestParam String title,
                              @RequestParam String overview,
                              @RequestParam String posterUrl) {
        UsuarioVO user = userService.getCurrentUser();
        PeliculaFavoritaVO fav = new PeliculaFavoritaVO();
        fav.setTitle(title);
        fav.setOverview(overview);
        fav.setPosterUrl(posterUrl);
        fav.setUser(user);
        favoriteRepo.save(fav);
        return "redirect:/favorites";
    }

    @GetMapping("/favorites")
    public String favorites(Model model) {
        UsuarioVO user = userService.getCurrentUser();
        model.addAttribute("favorites", favoriteRepo.findByUser(user));
        return "favorites";
    }
}
