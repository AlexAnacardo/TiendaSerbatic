package com.PeliculasSerbatic.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PeliculasSerbatic.model.UsuarioVO;
import com.PeliculasSerbatic.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;

    public void register(String username, String password) {
        UsuarioVO user = new UsuarioVO();
        user.setUsername(username);
        user.setPassword(password);
        userRepository.save(user);
    }

	@Override
	public UsuarioVO getCurrentUser() {
		// TODO Auto-generated method stub
		return null;
	}
}
