package com.PeliculasSerbatic.service;

import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.PeliculasSerbatic.controller.OpenAiController;
import com.PeliculasSerbatic.model.Answer;
import com.PeliculasSerbatic.model.Question;

@Service
public class OpenAiServiceImpl implements OpenAiService{

	private final OpenAiController openAIController;

	private final ChatModel chatModel;
	
	@Value("classpath:templates/CapitalPrompt.st")
	private Resource capitalPrompt;
	
	@Value("classpath:templates/CapitalPromptWithInfo.st")
	private Resource capitalPromptWithInfo;
	

	@Value("classpath:templates/CapitalPromptFormat.st")
	private Resource capitalPromptFormat;
	
	public OpenAiServiceImpl(ChatModel chatModel) {
        this.openAIController = new OpenAiController();
		this.chatModel = chatModel;
    }
	
	@Override
	public String getAnswer(String question) {
		PromptTemplate pt = new PromptTemplate(question);
		Prompt prompt =  pt.create();
		
		ChatResponse response = chatModel.call(prompt);
		return response.getResult().getOutput().getText();
	}

	@Override
	public Answer getAnswer(Question question) {
		PromptTemplate pt = new PromptTemplate(question.question());
		Prompt prompt =  pt.create();
		ChatResponse response = chatModel.call(prompt);
		Answer answer = new Answer(response.getResult().getOutput().getText());
		return answer;
	}

}
