package com.PeliculasSerbatic.service;

import java.util.List;

import com.PeliculasSerbatic.model.PeliculaVO;

public interface MovieService {
	public List<PeliculaVO> getTrendingMovies();
	
	public List<PeliculaVO> searchMovies(String query);
}
