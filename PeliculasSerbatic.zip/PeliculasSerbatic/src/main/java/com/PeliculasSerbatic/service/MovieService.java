package com.PeliculasSerbatic.service;

import java.util.List;

import com.PeliculasSerbatic.model.Movie;

public interface MovieService {
	public List<Movie> getTrendingMovies();
	
	public List<Movie> searchMovies(String query);
	
}
