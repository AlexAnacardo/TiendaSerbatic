package com.PeliculasSerbatic.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.PeliculasSerbatic.model.PeliculaVO;

@Service
public class MovieServiceImpl implements MovieService{

    @Value("${tmdb.api.key}")  
    private String apiKey;

    private final RestTemplate restTemplate;

    public MovieServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<PeliculaVO> getTrendingMovies() {
        String url = "https://api.themoviedb.org/3/trending/movie/day?api_key=" + apiKey;
        ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

        List<Map<String, Object>> results = (List<Map<String, Object>>) response.getBody().get("results");

        return results.stream().limit(10).map(result -> new PeliculaVO(
            (String) result.get("title"),
            (String) result.get("overview"),
            "https://image.tmdb.org/t/p/w500" + result.get("poster_path")
        )).collect(Collectors.toList());
    }

    public List<PeliculaVO> searchMovies(String query) {
        String url = "https://api.themoviedb.org/3/search/movie?api_key=" + apiKey + "&query=" + query;
        ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

        List<Map<String, Object>> results = (List<Map<String, Object>>) response.getBody().get("results");

        return results.stream().limit(10).map(result -> new PeliculaVO(
            (String) result.get("title"),
            (String) result.get("overview"),
            "https://image.tmdb.org/t/p/w500" + result.get("poster_path")
        )).collect(Collectors.toList());
    }
}
