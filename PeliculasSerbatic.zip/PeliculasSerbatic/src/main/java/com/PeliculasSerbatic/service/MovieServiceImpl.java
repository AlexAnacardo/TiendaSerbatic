package com.PeliculasSerbatic.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.PeliculasSerbatic.model.Movie;

@Service
public class MovieServiceImpl implements MovieService{

    @Value("${tmdb.api.key}")  // Inyectar la API key desde el archivo de propiedades
    private String apiKey;

    private final RestTemplate restTemplate;

    public MovieServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // Método para obtener películas populares (trending)
    public List<Movie> getTrendingMovies() {
        String url = "https://api.themoviedb.org/3/trending/movie/day?api_key=" + apiKey;
        ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

        // Extraer la lista de resultados
        List<Map<String, Object>> results = (List<Map<String, Object>>) response.getBody().get("results");

        // Mapear los resultados a una lista de objetos Movie
        return results.stream().limit(10).map(result -> new Movie(
            (String) result.get("title"),
            (String) result.get("overview"),
            "https://image.tmdb.org/t/p/w500" + result.get("poster_path")
        )).collect(Collectors.toList());
    }

    // Método para buscar películas por nombre
    public List<Movie> searchMovies(String query) {
        String url = "https://api.themoviedb.org/3/search/movie?api_key=" + apiKey + "&query=" + query;
        ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

        // Extraer la lista de resultados
        List<Map<String, Object>> results = (List<Map<String, Object>>) response.getBody().get("results");

        // Mapear los resultados a una lista de objetos Movie
        return results.stream().limit(10).map(result -> new Movie(
            (String) result.get("title"),
            (String) result.get("overview"),
            "https://image.tmdb.org/t/p/w500" + result.get("poster_path")
        )).collect(Collectors.toList());
    }
}
