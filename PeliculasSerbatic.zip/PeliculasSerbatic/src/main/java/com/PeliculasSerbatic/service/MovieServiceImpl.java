package com.PeliculasSerbatic.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.PeliculasSerbatic.model.Movie;

@Service
public class MovieServiceImpl implements MovieService{

    @Value("${tmdb.api.key}")  // Inyectar la API key desde el archivo de propiedades
    private String apiKey;

    private final RestTemplate restTemplate;

    public MovieServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /*
    // Método para obtener películas populares (trending)
    public List<Movie> getTrendingMovies() {
        String url = "https://api.themoviedb.org/3/trending/movie/day?api_key=" + apiKey;
        ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

        // Extraer la lista de resultados
        List<Map<String, Object>> results = (List<Map<String, Object>>) response.getBody().get("results");

        // Mapear los resultados a una lista de objetos Movie
        return results.stream().limit(10).map(result -> new Movie(
            (String) result.get("title"),
            (String) result.get("overview"),
            "https://image.tmdb.org/t/p/w500" + result.get("poster_path")
        )).collect(Collectors.toList());
    }
	*/
    
    public List<Movie> getTrendingMovies() {
        try {
            String url = "https://api.themoviedb.org/3/trending/movie/day?api_key=" + apiKey;
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

            List<Map<String, Object>> results = (List<Map<String, Object>>) response.getBody().get("results");

            // Log para ver si tenemos datos
            System.out.println("🔍 Películas obtenidas de TMDB: " + results.size());

            // Mapear los resultados a objetos Movie, usando tmdbId como clave primaria
            return results.stream().limit(10).map(result -> {
                Integer tmdbId = (Integer) result.get("id");  // Usar el id de TMDB como clave primaria
                String title = (String) result.get("title");
                String overview = (String) result.get("overview");
                String posterUrl = "https://image.tmdb.org/t/p/w500" + result.get("poster_path");

                return new Movie(tmdbId, title, overview, posterUrl);  // Aquí pasamos el tmdbId como ID
            }).collect(Collectors.toList());

        } catch (Exception e) {
            System.err.println("⚠️ Error al obtener películas trending: " + e.getMessage());
            e.printStackTrace();
            return List.of(); // Devolver lista vacía para evitar fallos
        }
    }



    
    public List<Movie> searchMovies(String query) {
        try {
            String url = "https://api.themoviedb.org/3/search/movie?api_key=" + apiKey + "&query=" + query;
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

            // Extraer la lista de resultados
            List<Map<String, Object>> results = (List<Map<String, Object>>) response.getBody().get("results");

            // Log para ver si tenemos resultados
            System.out.println("🔍 Resultados de búsqueda para '" + query + "': " + results.size());

            // Mapear los resultados a objetos Movie, usando tmdbId como clave primaria
            return results.stream().limit(10).map(result -> {
                Integer tmdbId = (Integer) result.get("id");  // Usar el id de TMDB como clave primaria
                String title = (String) result.get("title");
                String overview = (String) result.get("overview");
                String posterUrl = "https://image.tmdb.org/t/p/w500" + result.get("poster_path");

                return new Movie(tmdbId, title, overview, posterUrl);  // Aquí pasamos el tmdbId como ID
            }).collect(Collectors.toList());

        } catch (Exception e) {
            System.err.println("⚠️ Error al buscar películas: " + e.getMessage());
            e.printStackTrace();
            return List.of(); // Devolver lista vacía en caso de error
        }
    }

}
