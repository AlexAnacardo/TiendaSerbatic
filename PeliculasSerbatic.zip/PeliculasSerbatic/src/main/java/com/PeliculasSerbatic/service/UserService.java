package com.PeliculasSerbatic.service;

public interface UserService {
	public void register(String username, String password);
}
