package com.PeliculasSerbatic.service;

import com.PeliculasSerbatic.model.UsuarioVO;

public interface UserService {
	public void register(String username, String password);
	public UsuarioVO getCurrentUser();
}
