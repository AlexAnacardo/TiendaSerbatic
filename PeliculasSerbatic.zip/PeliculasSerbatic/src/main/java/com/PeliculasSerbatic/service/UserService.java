package com.PeliculasSerbatic.service;

import java.util.List;
import java.util.Optional;

import com.PeliculasSerbatic.model.User;

public interface UserService {
	public void register(String email, String username, String password);

	public User getByEmail(String email);

	public List<User> findAll();
	
	public void deleteUser(String email);
}
