package com.PeliculasSerbatic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PeliculasSerbatic.model.Reseña;
import com.PeliculasSerbatic.model.User;
import com.PeliculasSerbatic.repository.ReseñaRepository;

@Service
public class ReseñaServiceImpl implements ReseñaService{
	
	@Autowired
    private ReseñaRepository reseñaRepository;
	
	public List<Reseña> findByUser(User user) {
	    return reseñaRepository.findByUser(user); 
	}
}
