package com.PeliculasSerbatic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeliculasSerbaticApplicationTests {

	@Test
	void contextLoads() {
	}

}
