package com.PeliculasSerbatic.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.PeliculasSerbatic.model.Actor;
import com.PeliculasSerbatic.model.Movie;
import com.PeliculasSerbatic.model.MovieDetails;

@Service
public class MovieServiceImpl implements MovieService{

    @Value("${tmdb.api.key}")  // Inyectar la API key desde el archivo de propiedades
    private String apiKey;

    private final RestTemplate restTemplate;

    public MovieServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
    
    public List<Movie> getTrendingMovies() {
        try {
            String url = "https://api.themoviedb.org/3/trending/movie/day?api_key=" + apiKey + "&language=es-ES";
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

            List<Map<String, Object>> results = (List<Map<String, Object>>) response.getBody().get("results");

            // Mapear los resultados a objetos Movie, usando tmdbId como clave primaria
            return results.stream().limit(10).map(result -> {
                Integer tmdbId = (Integer) result.get("id");  // Usar el id de TMDB como clave primaria
                String title = (String) result.get("title");
                String overview = (String) result.get("overview");
                String posterUrl = "https://image.tmdb.org/t/p/w500" + result.get("poster_path");

                return new Movie(tmdbId, title, overview, posterUrl);  // Aquí pasamos el tmdbId como ID
            }).collect(Collectors.toList());

        } catch (Exception e) {
            System.err.println("⚠️ Error al obtener películas trending: " + e.getMessage());
            e.printStackTrace();
            return List.of(); // Devolver lista vacía para evitar fallos
        }
    }
     
    public List<Movie> searchMovies(String query) {
        try {
            String url = "https://api.themoviedb.org/3/search/movie?api_key=" + apiKey + "&query=" + query + "&language=es-ES";
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);

            // Extraer la lista de resultados
            List<Map<String, Object>> results = (List<Map<String, Object>>) response.getBody().get("results");

            // Mapear los resultados a objetos Movie, usando tmdbId como clave primaria
            return results.stream().limit(10).map(result -> {
                Integer tmdbId = (Integer) result.get("id");  // Usar el id de TMDB como clave primaria
                String title = (String) result.get("title");
                String overview = (String) result.get("overview");
                String posterUrl = "https://image.tmdb.org/t/p/w500" + result.get("poster_path");

                return new Movie(tmdbId, title, overview, posterUrl);  // Aquí pasamos el tmdbId como ID
            }).collect(Collectors.toList());

        } catch (Exception e) {
            System.err.println("⚠️ Error al buscar películas: " + e.getMessage());
            e.printStackTrace();
            return List.of(); // Devolver lista vacía en caso de error
        }
    }
    
    public Optional<MovieDetails> obtenerDetallesDePelicula(Integer tmdbId) {
        try {
            String url = "https://api.themoviedb.org/3/movie/" + tmdbId + "?api_key=" + apiKey + "&language=es-ES";
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject jsonResponse = new JSONObject(response.toString());

            String title = jsonResponse.getString("title");
            String overview = jsonResponse.getString("overview");
            String posterPath = jsonResponse.optString("poster_path", "");
            String releaseDate = jsonResponse.optString("release_date", "Desconocida");
            Double popularity = jsonResponse.optDouble("popularity", 0.0);
            String posterUrl = "https://image.tmdb.org/t/p/w500" + posterPath;

            MovieDetails movieDetails = new MovieDetails(title, overview, posterUrl, releaseDate, popularity);
            return Optional.of(movieDetails);

        } catch (Exception e) {
            e.printStackTrace();
            return Optional.empty();
        }
    }

    public List<Actor> obtenerReparto(Integer tmdbId) {
        List<Actor> reparto = new ArrayList<>();
        try {
            String url = "https://api.themoviedb.org/3/movie/" + tmdbId + "/credits?api_key=" + apiKey + "&language=es-ES";
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject json = new JSONObject(response.toString());
            JSONArray castArray = json.getJSONArray("cast");

            for (int i = 0; i < Math.min(10, castArray.length()); i++) {
                JSONObject actorJson = castArray.getJSONObject(i);
                String name = actorJson.getString("name");
                String character = actorJson.getString("character");
                String profilePath = actorJson.optString("profile_path", null);
                String profileUrl = (profilePath != null) ? "https://image.tmdb.org/t/p/w185" + profilePath : "https://via.placeholder.com/185x278?text=Sin+Foto";

                reparto.add(new Actor(name, profileUrl));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return reparto;
    }
}
