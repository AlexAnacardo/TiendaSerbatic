package com.PeliculasSerbatic.service;

import java.util.List;
import java.util.Optional;

import com.PeliculasSerbatic.model.Actor;
import com.PeliculasSerbatic.model.Movie;
import com.PeliculasSerbatic.model.MovieDetails;

public interface MovieService {
	public List<Movie> getTrendingMovies();
	
	public List<Movie> searchMovies(String query);
	
	public Optional<MovieDetails> obtenerDetallesDePelicula(Integer tmdbId);
	
	public List<Actor> obtenerReparto(Integer tmdbId);
	
}
