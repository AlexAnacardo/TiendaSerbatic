package com.PeliculasSerbatic.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.PeliculasSerbatic.model.Actor;
import com.PeliculasSerbatic.model.FavoriteMovie;
import com.PeliculasSerbatic.model.FavoriteMovieId;
import com.PeliculasSerbatic.model.Movie;
import com.PeliculasSerbatic.model.MovieDetails;
import com.PeliculasSerbatic.model.Reseña;
import com.PeliculasSerbatic.model.User;
import com.PeliculasSerbatic.repository.FavoriteMovieRepository;
import com.PeliculasSerbatic.repository.MovieRepository;
import com.PeliculasSerbatic.repository.ReseñaRepository;
import com.PeliculasSerbatic.service.MovieService;
import com.PeliculasSerbatic.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class MovieController {

    @Autowired
    private MovieService movieService;

    @Autowired
    private FavoriteMovieRepository favoriteRepo;
    
    @Autowired
    private MovieRepository movieRepo;
    
    @Autowired
    private ReseñaRepository reviewRepo;

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String index(Model model, HttpSession session) {
        List<Movie> trending = movieService.getTrendingMovies(); 
        model.addAttribute("movies", trending);
        session.setAttribute("cabeceraPagina", "Buscador de peliculas");
        
        return "index";
    }

    @PostMapping("/search")
    public String search(@RequestParam("query") String query, Model model) {
        List<Movie> movies = movieService.searchMovies(query);
        model.addAttribute("movies", movies);
        return "index";
    }
    
    

    @PostMapping("/añadirFavorita")
    public String addFavorite(@RequestParam("tmdbId") Integer tmdbId,
                              @RequestParam("title") String title,
                              @RequestParam("overview") String overview,
                              @RequestParam("posterUrl") String posterUrl,
                              HttpSession session) {

        User user = (User) session.getAttribute("usuarioEnCurso");

        if (user != null) {
            // Buscar o crear la película por ID
            Movie movie = movieRepo.findById(tmdbId).orElseGet(() -> {
                Movie newMovie = new Movie(tmdbId, title, overview, posterUrl);
                return movieRepo.save(newMovie);
            });

            // Crear ID compuesto
            FavoriteMovieId favId = new FavoriteMovieId(user.getEmail(), movie.getTmdbId());

            // Verificar si ya existe como favorita
            if (!favoriteRepo.existsById(favId)) {
                FavoriteMovie favorite = new FavoriteMovie();
                favorite.setId(favId);
                favorite.setUser(user);
                favorite.setMovie(movie);
                favoriteRepo.save(favorite);
            }

            return "redirect:/";
        } else {
            return "redirect:/goLogin";
        }
    }

    @PostMapping("/eliminarFavorita")
    public String deleteFavorite(@RequestParam("tmdbId") Integer tmdbId, HttpSession session) {

        User user = (User) session.getAttribute("usuarioEnCurso");
        
        favoriteRepo.deleteById(new FavoriteMovieId(user.getEmail() ,tmdbId));
        
        return "redirect:/favorites";
    }

    @GetMapping("/favorites")
    public String favorites(Model model, HttpSession session) {
        // Obtener el usuario actual de la sesión
        User usuarioEnCurso = (User) session.getAttribute("usuarioEnCurso");

        if (usuarioEnCurso != null) {
            // Buscar las películas favoritas asociadas al email del usuario
            List<FavoriteMovie> favoriteMovies = favoriteRepo.findByUserEmail(usuarioEnCurso.getEmail());

            // Extraer las películas favoritas de la lista de FavoriteMovie
            List<Movie> movies = favoriteMovies.stream()
                                               .map(FavoriteMovie::getMovie)  // Obtener la película desde FavoriteMovie
                                               .collect(Collectors.toList());

            model.addAttribute("favorites", movies);  // Pasar las películas al modelo
            session.setAttribute("cabeceraPagina", "Listado de peliculas favoritas");
            
            return "favorites";  // Devolver la vista de favoritas
        } else {
        	return "login";
        } 
    }
     
    
    @GetMapping("/verMas")
    public String verDetalles(@RequestParam("tmdbId") Integer tmdbId, Model model) {
        Optional<MovieDetails> optionalDetails = movieService.obtenerDetallesDePelicula(tmdbId);

        if (optionalDetails.isPresent()) {
        	List<Actor> cast = movieService.obtenerReparto(tmdbId);
        	List<Reseña> reviews = reviewRepo.findByMovieTmdbId(tmdbId);
        	model.addAttribute("reparto", cast);
            model.addAttribute("movieDetails", optionalDetails.get());
            model.addAttribute("reviews", reviews);
            model.addAttribute("idPelicula", tmdbId);
            
            model.addAttribute("title", optionalDetails.get().getTitle());
            model.addAttribute("overview", optionalDetails.get().getOverview());
            model.addAttribute("posterUrl", optionalDetails.get().getPosterUrl());
        } else {
            model.addAttribute("movieDetails", null);
            model.addAttribute("error", "No se encontraron detalles de la película o ocurrió un error al conectarse con la API.");
        }
        

        return "detallesPelicula";
    }

    


}
