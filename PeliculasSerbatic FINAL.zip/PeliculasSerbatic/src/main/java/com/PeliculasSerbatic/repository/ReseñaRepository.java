package com.PeliculasSerbatic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PeliculasSerbatic.model.Reseña;
import com.PeliculasSerbatic.model.User;

@Repository
public interface ReseñaRepository extends JpaRepository<Reseña, Integer> {
    List<Reseña> findByMovieTmdbId(Integer tmdbId);
    
    List<Reseña> findByUser(User user);
}
