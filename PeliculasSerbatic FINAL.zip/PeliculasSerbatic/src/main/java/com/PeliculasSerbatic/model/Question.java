package com.PeliculasSerbatic.model;

public record Question(String question) {

}
