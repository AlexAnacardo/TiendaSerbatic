package com.PeliculasSerbatic.controller;

import org.jsoup.Jsoup;
import org.jsoup.safety.Safelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.PeliculasSerbatic.model.User;
import com.PeliculasSerbatic.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @GetMapping("/goLogin")
    public String goLogin(HttpSession sesion) {
    	sesion.setAttribute("cabeceraPagina", "Iniciar sesion");
        return "login";
    }
    

    @PostMapping("/login")
    public String hacerLogin(@RequestParam(name = "user") String email, @RequestParam(name = "pass") String pass, Model model, HttpSession sesion) {
		
    	if (email == null || email.trim().isEmpty() || pass == null || pass.trim().isEmpty()) {
    		model.addAttribute("errorLogin", "Los campos no pueden estar vacios");
            return "login";
        }
    	
    	String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        if (!email.matches(emailPattern)) {
            model.addAttribute("errorLogin", "El formato del correo electrónico no es válido.");
            return "login";
        }
        
    	email = Jsoup.clean(email, Safelist.basic()); //Esto elimina contenido malicioso y protege frente a inyeccion de codigo
    	pass = Jsoup.clean(pass, Safelist.basic());
    	
		User usuario = userService.getByEmail(email);
		
		if(usuario!=null && passwordEncoder.matches(pass, usuario.getPassword())) {
			
			sesion.setAttribute("usuarioEnCurso", usuario);			
			
			return "redirect:/";
		}
		else {
			model.addAttribute("errorLogin", "Usuario no encontrado/contraseña incorrecta");
			return "login";
		}
    }
    
    @GetMapping("/logout")
    public String hacerLogout(HttpSession sesion) {
    	
    	sesion.removeAttribute("usuarioEnCurso");
    	
    	return "redirect:/";
    }
    
    @GetMapping("/goRegister")
    public String goRegister(HttpSession sesion) {
    	sesion.setAttribute("cabeceraPagina", "Registrarse");
        return "register";
    }

    @PostMapping("/register")
    public String processRegister(@RequestParam("email") String email, @RequestParam("username") String username, @RequestParam("password") String password, HttpSession sesion, Model model) {   	
    	
    	if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
    		model.addAttribute("errorRegister", "Los campos no pueden estar vacios");
            return "register";
        }
    	
    	String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        if (!email.matches(emailPattern)) {
            model.addAttribute("errorRegister", "El formato del correo electrónico no es válido.");
            return "register";
        }
    	
    	email = Jsoup.clean(email, Safelist.basic()); //Esto elimina contenido malicioso y protege frente a inyeccion de codigo
    	password = Jsoup.clean(password, Safelist.basic());
    	
    	if(userService.getByEmail(email)==null) {
    		User usuario=new User(email, username, password);    	
        	
        	userService.register(usuario.getEmail(), usuario.getUsername(), usuario.getPassword());
        	
        	sesion.setAttribute("usuarioEnCurso", usuario);
        	
            return "redirect:/";
    	} else {
    		return "register";
    	}
    }
    
}
