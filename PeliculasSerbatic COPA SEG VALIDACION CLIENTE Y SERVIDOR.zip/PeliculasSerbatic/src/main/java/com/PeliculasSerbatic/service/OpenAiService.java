package com.PeliculasSerbatic.service;

import com.PeliculasSerbatic.model.Answer;
import com.PeliculasSerbatic.model.Question;

public interface OpenAiService {
	public String getAnswer(String question);
	public Answer getAnswer(Question question);
}
