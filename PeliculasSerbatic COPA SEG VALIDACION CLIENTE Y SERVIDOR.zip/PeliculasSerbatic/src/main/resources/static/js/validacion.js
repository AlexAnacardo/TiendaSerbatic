// utils: sanitiza entradas para evitar inyecciones de scripts
function containsMaliciousCode(input) {
    const pattern = /<[^>]*script|on\w+=|javascript:|<[^>]+>/gi;
    return pattern.test(input);
}

// Validación formulario de reseña
function validateReviewForm() {
    const reviewContent = document.querySelector('textarea[name="content"]').value.trim();

    if (reviewContent === "") {
        alert("Por favor, escribe una reseña.");
        return false;
    }

    if (containsMaliciousCode(reviewContent)) {
        alert("La reseña contiene código no permitido.");
        return false;
    }

    return true;
}

// Validación formulario de edición de usuario
function validateUserForm() {
    const username = document.querySelector('input[name="username"]').value.trim();

    if (username === "") {
        alert("Por favor, ingresa un nombre de usuario.");
        return false;
    }

    if (containsMaliciousCode(username)) {
        alert("El nombre de usuario contiene caracteres no permitidos.");
        return false;
    }

    return true;
}

// Validación formulario de login
function validateLoginForm() {
    const username = document.querySelector('input[name="user"]').value.trim();
    const password = document.querySelector('input[name="pass"]').value.trim();

    if (username === "" || password === "") {
        alert("Por favor, completa todos los campos.");
        return false;
    }

    if (containsMaliciousCode(username) || containsMaliciousCode(password)) {
        alert("Entrada inválida detectada.");
        return false;
    }

    return true;
}

// Validación formulario de registro
function validateRegisterForm() {
    const email = document.querySelector('input[name="email"]').value.trim();
    const username = document.querySelector('input[name="username"]').value.trim();
    const password = document.querySelector('input[name="password"]').value.trim();

    if (email === "" || username === "" || password === "") {
        alert("Por favor, completa todos los campos.");
        return false;
    }

    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailRegex.test(email)) {
        alert("Por favor, ingresa un correo electrónico válido.");
        return false;
    }

    if (containsMaliciousCode(username) || containsMaliciousCode(password)) {
        alert("El formulario contiene datos inválidos.");
        return false;
    }

    return true;
}
