package es.serbatic.ProyectoSerbatic.service;

import es.serbatic.ProyectoSerbatic.model.CompraVO;

public interface CompraService {
	public void insertar(CompraVO compra);
	
	public int getByUser(Long idCliente);
}