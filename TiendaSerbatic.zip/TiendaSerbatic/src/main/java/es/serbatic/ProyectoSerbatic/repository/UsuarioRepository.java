package es.serbatic.ProyectoSerbatic.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import es.serbatic.ProyectoSerbatic.model.UsuarioVO;

public interface UsuarioRepository extends JpaRepository<UsuarioVO, Long>{

    UsuarioVO findByUser(String user);

}
