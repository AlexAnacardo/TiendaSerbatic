package es.serbatic.ProyectoSerbatic.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import es.serbatic.ProyectoSerbatic.model.CompraVO;

public interface CompraRepository extends JpaRepository<CompraVO, CompraVO.CompraId>{
	int countByIdCliente(Long idCliente);
}