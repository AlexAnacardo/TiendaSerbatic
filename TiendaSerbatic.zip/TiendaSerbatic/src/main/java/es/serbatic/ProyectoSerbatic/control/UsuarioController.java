package es.serbatic.ProyectoSerbatic.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import es.serbatic.ProyectoSerbatic.model.UsuarioVO;
import es.serbatic.ProyectoSerbatic.service.ProductoService;
import es.serbatic.ProyectoSerbatic.service.UsuarioService;
import jakarta.servlet.http.HttpSession;

@Controller
public class UsuarioController {
	
	@Autowired
	UsuarioService service;
	
	@Autowired
	ProductoService productoService;
	
	@PostMapping("/login")
    public String hacerLogin(@RequestParam(name = "user") String user, @RequestParam(name = "pass") String pass, Model model, HttpSession sesion) {
		
		UsuarioVO usuario = service.getByUser(user);
		
		if(usuario!=null && usuario.getPass().equals(pass)) {
			sesion.setAttribute("usuarioEnCurso", usuario);			
			model.addAttribute("catalogo", this.productoService.getAll());
			return "index";
		}
		else {
			return "login";
		}
    }
	
	@PostMapping("/altaUsuario")
    public String altaUsuario(@RequestParam(name = "user") String user, @RequestParam(name = "pass") String pass, Model model, HttpSession sesion) {
        UsuarioVO usuario = new UsuarioVO(user, pass);
        this.service.insertar(usuario);
        model.addAttribute("catalogo", this.productoService.getAll());
        return "index";
    }	
}
