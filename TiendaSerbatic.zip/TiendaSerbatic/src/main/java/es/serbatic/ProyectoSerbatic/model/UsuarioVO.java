package es.serbatic.ProyectoSerbatic.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "usuarioprueba")
public class UsuarioVO {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
    private Long id;
	
	@Column(name = "user")
	private String user;
	
	@Column(name = "pass")
	private String pass;
	
	public UsuarioVO() {}
	
	public UsuarioVO(String user, String pass) {
		this.user=user;
		this.pass=pass;
	}
	
	public boolean getTerms() { 
        return false;
    }


	public Long getId() {
		return this.id;
	}
	
	public String getUser() {
		return this.user;
	}
	
	public String getPass() {
		return this.pass;
	}
}
