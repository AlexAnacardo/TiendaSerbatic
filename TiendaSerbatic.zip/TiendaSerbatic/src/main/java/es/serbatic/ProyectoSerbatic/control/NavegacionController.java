package es.serbatic.ProyectoSerbatic.control;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import es.serbatic.ProyectoSerbatic.model.ProductoVO;
import es.serbatic.ProyectoSerbatic.service.ProductoService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class NavegacionController {
	
	@Autowired
	ProductoService productoService;
	
	@GetMapping("/")
	public String goIndex(Model model, HttpServletRequest request) {
		model.addAttribute("catalogo", this.productoService.getAll());
		return "index";
	}
	
	@GetMapping("/verCarrito")
	public String accederCarrito(Model model, HttpSession sesion) {
			
			
		HashMap<ProductoVO, Integer> carrito = (HashMap<ProductoVO, Integer>) sesion.getAttribute("carrito");
				
		if(carrito == null) {			
			carrito = new HashMap<ProductoVO, Integer>();
		}
			
		double totalCarrito = 0.0;
	    for (Map.Entry<ProductoVO, Integer> entry : carrito.entrySet()) {
	        ProductoVO producto = entry.getKey();
	        int cantidad = entry.getValue();
	        totalCarrito += producto.getPrecio() * cantidad;
	    }
	    
		model.addAttribute("carrito", carrito);
		model.addAttribute("totalCarrito", totalCarrito);
		
		return "carrito";
	}
	
	@GetMapping("/loginUsuario")
	public String login(Model model, HttpSession sesion) {
		if(sesion.getAttribute("usuarioEnCurso") == null) {
			return "login";
		}
		else {
			return "redirect:/";
		}
	}
	
	@GetMapping("/registrarUsuario")
	public String registrarse(Model model, HttpSession sesion) {
		return "registro";
	}
	
	public String goPerfilUsuario() {		
		return "index";
	}
}