document.addEventListener("DOMContentLoaded", function(){
	
	const form=document.getElementById("formularioLogin");
	
	form.addEventListener("submit", function(event){
		
		let error=false;
		
		let nombreUsuario=document.getElementById("nombre").value;
		if(nombreUsuario.trim()===""){
			alert("El campo 'usuario' es obligatorio")
			error=true;
		}
		
		let contraseñaUsuario=document.getElementById("password").value;
		if(contraseñaUsuario.trim()===""){
			alert("El campo 'contraseña' es obligatorio")
			error=true;
		}
				
				
		if(error){		
			event.preventDefault();
		}
	});
});