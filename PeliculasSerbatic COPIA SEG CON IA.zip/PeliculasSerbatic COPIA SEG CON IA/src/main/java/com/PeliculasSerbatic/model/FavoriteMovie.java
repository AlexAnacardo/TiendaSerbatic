package com.PeliculasSerbatic.model;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;

@Entity
@Table(name = "favoritemovie")
public class FavoriteMovie {

	@EmbeddedId
    private FavoriteMovieId id;

    @ManyToOne
    @MapsId("email")
    @JoinColumn(name = "email_usuario")
    private User user;

    @ManyToOne
    @MapsId("movieId")
    @JoinColumn(name = "movie_id")
    private Movie movie;

    public FavoriteMovie() {}

    public FavoriteMovie(User user, Movie movie) {
        this.user = user;
        this.movie = movie;
        this.id = new FavoriteMovieId(user.getEmail(), movie.getTmdbId());
    }

    public FavoriteMovieId getId() {
        return id;
    }

    public void setId(FavoriteMovieId id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }
}
