package com.PeliculasSerbatic.model;

public record Answer(String answer) {

}
