package com.PeliculasSerbatic.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.PeliculasSerbatic.model.Movie;
import com.PeliculasSerbatic.model.Reseña;
import com.PeliculasSerbatic.model.User;
import com.PeliculasSerbatic.repository.MovieRepository;
import com.PeliculasSerbatic.repository.ReseñaRepository;
import com.PeliculasSerbatic.service.ReseñaService;
import com.PeliculasSerbatic.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UsuarioController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	ReseñaService reseñaService;
	
	@Autowired
	private ReseñaRepository reviewRepo;
	
	@Autowired
	private MovieRepository movieRepo;
	
	@PostMapping("/agregarReseña")
	public String addReview(@RequestParam("tmdbId") Integer tmdbId, 
	                        @RequestParam("content") String content,
	                        @RequestParam("title") String title,
                            @RequestParam("overview") String overview,
                            @RequestParam("posterUrl") String posterUrl, 
	                        HttpSession session, 
	                        Model model) {
		
		 System.out.println("tmdbId: " + tmdbId);
		    System.out.println("content: " + content);
		    System.out.println("title: " + title);
		    System.out.println("overview: " + overview);
		    System.out.println("posterUrl: " + posterUrl);

	    User user = (User) session.getAttribute("usuarioEnCurso");
	    System.out.println("Usuario en sesión al reseñar: " + session.getAttribute("usuarioEnCurso"));

	    if (user != null) {
	        // Buscar la película por su ID
	        Movie movie = movieRepo.findById(tmdbId).orElse(null);

	        if (movie == null) {
	            // Si la película no existe en la base de datos, creamos una nueva película
	            movie = new Movie();
	            movie.setTmdbId(tmdbId);
	            movie.setTitle(title);
	            movie.setOverview(overview);
	            movie.setPosterUrl(posterUrl);
	            
	            // Guardar la película en la base de datos
	            movieRepo.save(movie);
	        }

	        // Comprobar si ya existe una reseña del usuario para esta película
	        Reseña existingReview = reviewRepo.findByMovieTmdbId(tmdbId).stream()
	                .filter(r -> r.getUser().getEmail().equals(user.getEmail()))
	                .findFirst()
	                .orElse(null);

	        if (existingReview != null) {
	            // Si la reseña existe, actualizarla
	            existingReview.setContent(content);
	            reviewRepo.save(existingReview);
	        } else {
	            // Si no existe la reseña, crear una nueva
	            Reseña newReview = new Reseña(null, content, movie, user);
	            reviewRepo.save(newReview);
	        }

	        return "redirect:/verMas?tmdbId=" + tmdbId; // Volver a la página de detalles de la película
	    }

	    return "redirect:/goLogin";  // Redirigir a login si no está autenticado
	}

	
	@PostMapping("/eliminarReseña")
	public String deleteReview(@RequestParam("tmdbId") Integer tmdbId, 
	                           @RequestParam("reviewId") Integer reviewId, 
	                           HttpSession session) {

	    User user = (User) session.getAttribute("usuarioEnCurso");

	    if (user != null) {
	        Reseña review = reviewRepo.findById(reviewId).orElse(null);

	        if (review != null && review.getUser().getEmail().equals(user.getEmail())) {
	            // Eliminar la reseña
	            reviewRepo.delete(review);
	        }
	    }

	    return "redirect:/verMas?tmdbId=" + tmdbId;  // Redirigir de nuevo a la página de detalles
	}
	
	@GetMapping("/gestionUsuarios")
	public String gestionUsuarios(Model model, HttpSession session) {
		User user = (User) session.getAttribute("usuarioEnCurso");
		if(user.isAdministrador()) {
			List<User> usuarios = userService.findAll(); // Este método debe existir en tu servicio
	        model.addAttribute("usuarios", usuarios);
			
			session.setAttribute("cabeceraPagina", "Mantenimiento usuarios");
			return "mantenimientoUsuarios";
		} else {
			session.setAttribute("cabeceraPagina", "Iniciar sesion");
			return "redirect:/login";
		}
	}
	
	@GetMapping("/reseñas/{email}")
	public String verReseñasDeUsuario(@PathVariable("email") String email, Model model, HttpSession session) {
	    User user = userService.getByEmail(email); // Busca al usuario por su email
	    if (user == null) {
	        return "redirect:/gestionUsuarios"; // Si el usuario no existe, redirige a la gestión de usuarios
	    }

	    List<Reseña> reseñas = reseñaService.findByUser(user); // Obtiene las reseñas del usuario
	    model.addAttribute("usuario", user);
	    model.addAttribute("reseñas", reseñas); // Añade las reseñas al modelo

	    session.setAttribute("cabeceraPagina", "Reseñas de " + user.getUsername());
	    return "reseñasUsuario"; // La vista que mostrará las reseñas del usuario
	}

	@GetMapping("eliminarUsuario")
	public String eliminarUsuario(@RequestParam("email") String email) {
		userService.deleteUser(email);
		
		return "redirect:/gestionUsuarios";
	}
	
	
	@GetMapping("goEditarUsuario")
	public String goEditarUsuario(@RequestParam("email") String email, Model model) {
		
		User usuario = userService.getByEmail(email);
					
		model.addAttribute("emailUser", usuario.getEmail());
		model.addAttribute("usernameUser", usuario.getUsername());
		model.addAttribute("passwordUser", usuario.getPassword());
		
		
		return "edicionUsuario";
	}
	
	@PostMapping("editarUsuario")
	public String editarUsuario(@RequestParam("email") String email, @RequestParam("username") String username, @RequestParam("password") String password, HttpSession session) {
		
		userService.editUser(email, username, password);
				
		User usuarioSesion = (User) session.getAttribute("usuarioEnCurso");
		
		if(usuarioSesion.getEmail().equals(email)) {
			usuarioSesion.setUsername(username);
			usuarioSesion.setPassword(password);			
			
			session.setAttribute("usuarioEnCurso", usuarioSesion);		
		}
		
		return "redirect:/gestionUsuarios";
	}

}
